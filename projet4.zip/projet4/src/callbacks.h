#include <gtk/gtk.h>


void
on_login_et_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajouter_et_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficher_et_clicked                    (GtkButton       *button,
                                        gpointer         user_data);


void
on_supprimer_et_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_quitter_et_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_valider_et_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton2_et_gar__on_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_et_fille_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

//void
//on_valider_supp_clicked                (GtkButton       *button,
                                       // gpointer         user_data);

void
on_valider_mod_et_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_et_gar__on_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_et_fille_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_et_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_et_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton3_et_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton5_et_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ok_et_clicked                          (GtkButton       *button,
                                        gpointer         user_data);

void
on_valider_chercher_et_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_valider_chercher_et_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_valider_mod_et_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_ok_et_clicked                          (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_et_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_checkbutton4_et_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_valider_supp_et_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifier_et_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_et_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_quitterr_et_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_rechercher_et_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_quitter_et_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_quitterrr_et_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_niveau_et_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_resultat_et_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_et_clicked                      (GtkButton       *button,
                                        gpointer         user_data);


void
on_checkbutton1_et_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_et_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton3_et_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton4_et_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton5_et_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_login_clicked                     (GtkButton       *button,
                                        gpointer         user_data);
void
on_ajouter_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data);


void
on_supprimer_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_quitter_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_valider_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton2_gar__on_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_fille_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

//void
//on_valider_supp_clicked                (GtkButton       *button,
                                       // gpointer         user_data);

void
on_valider_mod_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_gar__on_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_fille_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ok_clicked                          (GtkButton       *button,
                                        gpointer         user_data);

void
on_valider_chercher_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_valider_chercher_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_valider_mod_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_ok_clicked                          (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_checkbutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_valider_supp_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_quitterr_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_rechercher_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_quitter_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_quitterrr_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_niveau_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_resultat_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_login_et_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_et_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_rechercher_et_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficher_et_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_et_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_niveau_et_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimer_et_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifier_et_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_quitterr_et_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajouter_et_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_quitter_et_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_valider_et_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_valider_mod_et_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_quitterrr_et_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_et_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_resultat_et_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_return_et_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbuttlvl2_et_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttlvl3_et_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttlvl4_et_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttlvl5_et_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttlvl1_et_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
